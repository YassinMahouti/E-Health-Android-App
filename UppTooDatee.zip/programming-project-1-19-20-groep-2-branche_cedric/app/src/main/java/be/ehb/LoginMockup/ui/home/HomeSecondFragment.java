package be.ehb.LoginMockup.ui.home;

import android.app.Fragment;

public class HomeSecondFragment extends Fragment {
}

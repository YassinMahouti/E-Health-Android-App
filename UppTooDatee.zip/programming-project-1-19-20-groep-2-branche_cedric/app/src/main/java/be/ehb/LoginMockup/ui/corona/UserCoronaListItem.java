package be.ehb.LoginMockup.ui.corona;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;import be.ehb.Ehealth.R;


public class UserCoronaListItem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_corona_list_item);
    }
}

package be.ehb.LoginMockup.ui.premium;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import be.ehb.Ehealth.R;

public class Premium extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_premium);

    }
}

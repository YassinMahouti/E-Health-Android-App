package be.ehb.LoginMockup.ui.Calorie;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import be.ehb.Ehealth.R;

public class CalorieCalc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie_calculator);




    }
}
